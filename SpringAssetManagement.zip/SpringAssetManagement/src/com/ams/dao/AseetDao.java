package com.ams.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class AseetDao {

	@PersistenceContext
	EntityManager entity=null;
}
