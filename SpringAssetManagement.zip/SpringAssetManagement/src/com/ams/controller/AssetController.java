package com.ams.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AssetController {

	@RequestMapping("home")
	public String getHome()
	{
		return "home";
	}
	
	@RequestMapping("login")
	public String getLoginPage()
	{
		return "login";
	}
	
	@RequestMapping("managerDashboard")
	public String getManagerDashboard()
	{
		return "managerDashboard";
	}
	
	@RequestMapping("raiseRequest")
	public String getRequestPage()
	{
		return "raiseRequest";
	}
	
	@RequestMapping("viewStatus")
	public String viewStatusPage()
	{
		return "viewStatus";
	}
	
}
